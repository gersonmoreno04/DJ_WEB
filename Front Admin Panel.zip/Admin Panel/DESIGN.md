---
name: Kinetic Night
colors:
  surface: '#131314'
  surface-dim: '#131314'
  surface-bright: '#3a393a'
  surface-container-lowest: '#0e0e0f'
  surface-container-low: '#1c1b1c'
  surface-container: '#201f20'
  surface-container-high: '#2a2a2b'
  surface-container-highest: '#353436'
  on-surface: '#e5e2e3'
  on-surface-variant: '#d3c1d6'
  inverse-surface: '#e5e2e3'
  inverse-on-surface: '#313031'
  outline: '#9c8ba0'
  outline-variant: '#4f4254'
  surface-tint: '#e8b3ff'
  primary: '#e8b3ff'
  on-primary: '#500074'
  primary-container: '#c960ff'
  on-primary-container: '#460066'
  inverse-primary: '#9600d4'
  secondary: '#d3fbff'
  on-secondary: '#00363a'
  secondary-container: '#00eefc'
  on-secondary-container: '#00686f'
  tertiary: '#abd600'
  on-tertiary: '#283500'
  tertiary-container: '#7c9c00'
  on-tertiary-container: '#222e00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#f6d9ff'
  primary-fixed-dim: '#e8b3ff'
  on-primary-fixed: '#310049'
  on-primary-fixed-variant: '#7200a3'
  secondary-fixed: '#7df4ff'
  secondary-fixed-dim: '#00dbe9'
  on-secondary-fixed: '#002022'
  on-secondary-fixed-variant: '#004f54'
  tertiary-fixed: '#c3f400'
  tertiary-fixed-dim: '#abd600'
  on-tertiary-fixed: '#161e00'
  on-tertiary-fixed-variant: '#3c4d00'
  background: '#131314'
  on-background: '#e5e2e3'
  surface-variant: '#353436'
typography:
  headline-2xl:
    fontFamily: Montserrat
    fontSize: 72px
    fontWeight: '900'
    lineHeight: 80px
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Montserrat
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Montserrat
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Montserrat
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
  section-gap: 120px
---

## Brand & Style

The design system is engineered for the high-intensity world of electronic music and premium event production. It evokes the atmosphere of a world-class nightclub: dark, immersive, and vibrating with energy. The target audience includes event promoters, festival organizers, and luxury hospitality brands seeking a professional yet cutting-edge aesthetic.

The visual style is a fusion of **Glassmorphism** and **High-Contrast Bold**. It relies on deep architectural blacks to provide a "void" where vibrant neon accents and high-fidelity photography can pop. The emotional response should be one of "controlled chaos"—sophisticated and rhythmic, yet undeniably energetic. Motion and depth are conveyed through layered translucent surfaces and localized light glows that mimic stage lighting.

## Colors

This design system uses a "True Dark" foundation to maximize the luminosity of the accent palette. 

- **Primary (Electric Purple):** Used for main calls to action and critical brand moments. It represents the energy of the nightlife.
- **Secondary (Cyan):** Used for interactive elements, highlights, and status indicators. It provides a digital, high-tech contrast.
- **Tertiary (Neon Lime):** Reserved for ultra-high-emphasis labels or "live" indicators, used sparingly to prevent visual fatigue.
- **Surface Palette:** Utilizes charcoal grays (#1A1A1C) for containers to create subtle separation from the #0A0A0B background without losing the dark aesthetic.

## Typography

Typography in the design system is rhythmic and structural. 

**Montserrat** is used for headlines to provide a bold, geometric presence. For the largest display sizes (2xl), apply a slight italic skew or tight tracking to enhance the sense of motion. **Inter** provides a highly legible, neutral balance for descriptions and long-form content, ensuring professionalism is maintained. **Geist** is utilized for technical data, timestamps, and metadata, lending a precise, "equipment-preset" feel to the interface. 

Always use high weight contrast (e.g., pairing a Black 900 headline with a Regular 400 body) to maintain the high-energy aesthetic.

## Layout & Spacing

The layout follows a **Fluid Grid** model with a heavy emphasis on asymmetrical balance. 

- **Desktop:** A 12-column grid with wide 64px margins. Content should often break the grid or use offset columns to create a "rhythmic" flow that isn't strictly linear.
- **Section Gaps:** Large vertical gaps (120px+) are encouraged to allow high-quality artist photography to serve as the visual anchor.
- **Mobile:** Transition to a 4-column grid with 16px margins. Stack elements vertically but maintain the "neon-glow" bleed effects off the edges of the screen to preserve depth.

## Elevation & Depth

Hierarchy is established through **Glassmorphism** and **Light Emission** rather than traditional shadows.

1.  **Background:** Deep Black (#0A0A0B).
2.  **Base Layer:** Charcoal surfaces with 1px low-opacity borders (White at 10% opacity).
3.  **Glass Layer:** Semi-transparent containers with a `backdrop-filter: blur(20px)` and a subtle `linear-gradient` (White at 5% to White at 0%).
4.  **Luminous Depth:** Active elements or "featured" cards should utilize a `box-shadow` with the Primary or Secondary color, set to a high blur (40px+) and low opacity (30%), creating a neon glow effect that appears to light up the surrounding UI.

## Shapes

The design system utilizes a "Rounded" language to soften the aggressive high-contrast colors, making the premium aesthetic feel more approachable. 

- **Standard Elements:** 0.5rem (Buttons, small cards).
- **Featured Cards:** 1rem (rounded-lg) for event posters and artist profiles.
- **Overlays:** 1.5rem (rounded-xl) for modals and major glass panels.
- **Interactive Triggers:** Use pill-shapes (rounded-full) for tags and chips to contrast against the structural rectangular grids.

## Components

### Buttons
Primary buttons use a solid gradient of Primary to Secondary colors with a white `label-md` text. On hover, trigger a neon outer glow. Secondary buttons use a "Ghost" style: 1px border with the primary color and no fill, until hovered.

### Glass Cards
The signature component. Use a dark background with 40% opacity and 20px backdrop blur. Borders must be 1px, top-left weighted light source (gradient border from White 20% to White 0%).

### Input Fields
Inputs are dark and recessed. Use a 1px Charcoal border that transitions to a Cyan glow when focused. Placeholder text should be low-contrast (White 30%).

### Chips & Tags
Small, pill-shaped elements with a Secondary (Cyan) border and Geist typography. For "Live" or "Sold Out" statuses, use the Tertiary (Neon Lime) color for maximum visibility.

### Lists
Lists should be borderless, using only vertical spacing and subtle Charcoal separators. Each list item should have a hover state that slightly increases the background luminosity, creating a "scanning" effect.

### Music Player/Waveform
A custom component for event previews. The waveform should be rendered in the Secondary color with a subtle glow, reactive to the mouse position.